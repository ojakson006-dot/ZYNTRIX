package com.turbo.game

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle

/** Janela transparente que só pede a autorização de captura (para medir o FPS ou gravar a tela) e fecha. */
class CapActivity : Activity() {
    private var mode = "fps"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        mode = intent?.getStringExtra("mode") ?: "fps"
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val i = if (Build.VERSION.SDK_INT >= 34)
                mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            else mpm.createScreenCaptureIntent()
            startActivityForResult(i, 78)
        } catch (e: Exception) {
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq == 78 && rc == RESULT_OK && d != null) {
            val cls = if (mode == "rec") RecordService::class.java else CaptureService::class.java
            startForegroundService(Intent(this, cls).putExtra("code", rc).putExtra("data", d))
        }
        finish()
    }
}
