package com.turbo.game

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Gravação de tela (só vídeo, sem áudio). O arquivo vai para Filmes/Turbo Game na galeria
 * (Android 10+) ou para a pasta do app (Android 8/9). Parar o serviço salva o arquivo.
 */
class RecordService : Service() {
    companion object {
        /** Gravando de verdade. */
        @Volatile var active = false
        /** Pedido aceito, ainda preparando (evita abrir a autorização duas vezes). */
        @Volatile var busy = false
        @Volatile var startedAt = 0L
    }

    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var rec: MediaRecorder? = null
    private var ht: HandlerThread? = null
    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var file: File? = null
    private var finished = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun dataOf(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java) else i?.getParcelableExtra("data")

    private fun toast(m: String) = ui.post { Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show() }

    /** Tamanho real da tela agora (já com a resolução personalizada, se houver). */
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    private fun even(v: Int) = maxOf(2, (v / 2) * 2)

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") {
            stopSelf()
            return START_NOT_STICKY
        }
        busy = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tg", "Turbo Game", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 3, Intent(this, RecordService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "tg")
            .setContentTitle("Turbo Game gravando a tela")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Parar", stop).build())
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else startForeground(3, n)
        } catch (e: Exception) {
            busy = false
            stopSelf()
            return START_NOT_STICKY
        }
        val code = i?.getIntExtra("code", 0) ?: 0
        val data = dataOf(i)
        if (data == null) {
            busy = false
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            val t = HandlerThread("tg-rec")
            t.start()
            ht = t
            val hd = Handler(t.looper)
            // Android 14+: o callback precisa existir antes de criar o display virtual
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, hd)
            proj = p
            // espera um instante: a janela de autorização fecha e o jogo volta (a orientação da tela se acerta)
            hd.postDelayed({ begin() }, 700)
        } catch (e: Exception) {
            busy = false
            toast("Não consegui iniciar a gravação")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun openOutput(r: MediaRecorder) {
        val name = "TurboGame_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Turbo Game")
            cv.put(MediaStore.Video.Media.IS_PENDING, 1)
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("sem armazenamento")
            uri = u
            val fd = contentResolver.openFileDescriptor(u, "rw") ?: throw IllegalStateException("sem armazenamento")
            pfd = fd
            r.setOutputFile(fd.fileDescriptor)
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            dir.mkdirs()
            val fl = File(dir, name)
            file = fl
            r.setOutputFile(fl.absolutePath)
        }
    }

    /** Descarta uma tentativa que falhou (apaga o arquivo vazio). */
    private fun discard() {
        try { vd?.release() } catch (e: Exception) {}
        vd = null
        try { rec?.release() } catch (e: Exception) {}
        rec = null
        try { pfd?.close() } catch (e: Exception) {}
        pfd = null
        uri?.let { try { contentResolver.delete(it, null, null) } catch (e: Exception) {} }
        uri = null
        file?.let { try { it.delete() } catch (e: Exception) {} }
        file = null
    }

    private fun tryStart(fps: Int): Boolean {
        val p = proj ?: return false
        val sz = screenSize()
        var w = sz.first
        var h = sz.second
        // limita o maior lado a 1920 (o codificador de vídeo da maioria dos celulares aceita)
        val big = maxOf(w, h)
        if (big > 1920) {
            val k = 1920f / big
            w = Math.round(w * k)
            h = Math.round(h * k)
        }
        w = even(w)
        h = even(h)
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            rec = r
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setVideoSize(w, h)
            r.setVideoFrameRate(fps)
            r.setVideoEncodingBitRate(minOf(16_000_000L, w.toLong() * h * 4).toInt())
            openOutput(r)
            r.prepare()
            val dpi = resources.displayMetrics.densityDpi
            vd = p.createVirtualDisplay("tg-rec", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            r.start()
            true
        } catch (e: Exception) {
            discard()
            false
        }
    }

    private fun begin() {
        if (finished) return
        if (!tryStart(60) && !tryStart(30)) {
            busy = false
            toast("O aparelho não conseguiu gravar a tela")
            stopSelf()
            return
        }
        startedAt = SystemClock.elapsedRealtime()
        active = true
        busy = false
        toast("Gravando a tela")
    }

    /** Fecha o arquivo e libera tudo (só roda uma vez). */
    private fun finish() {
        if (finished) return
        finished = true
        val wasActive = active
        active = false
        busy = false
        var good = wasActive
        if (wasActive) {
            try {
                rec?.stop()
            } catch (e: Exception) {
                good = false // parou rápido demais: o arquivo ficou sem quadros
            }
        }
        try { vd?.release() } catch (e: Exception) {}
        try { rec?.release() } catch (e: Exception) {}
        try { proj?.stop() } catch (e: Exception) {}
        try { pfd?.close() } catch (e: Exception) {}
        val u = uri
        if (u != null) {
            try {
                if (good) {
                    val cv = ContentValues()
                    cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                    contentResolver.update(u, cv, null, null)
                } else {
                    contentResolver.delete(u, null, null)
                }
            } catch (e: Exception) {
            }
        }
        val fl = file
        if (fl != null && !good) try { fl.delete() } catch (e: Exception) {}
        try { ht?.quitSafely() } catch (e: Exception) {}
        if (wasActive) {
            toast(
                if (!good) "A gravação ficou curta demais e não foi salva"
                else if (u != null) "Gravação salva em Filmes/Turbo Game"
                else "Gravação salva em " + (fl?.parent ?: "pasta do app")
            )
        }
    }

    override fun onDestroy() {
        finish()
        super.onDestroy()
    }
}
